<?php

namespace App\Http\Controllers;

use App\Exports\PersonalisBsm2Export;
use App\Imports\SheetImport;
use App\Models\PersonalisBsm2;
use App\Models\PersonalisBsm2Sheet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class PersonalisBsm2Controller extends Controller
{
    public function index()
    {
        $personalis_bsm_2_sheets = PersonalisBsm2Sheet::all();
        // dd($personalis_bsm_sheets);
        return view('personalis_bsm2.index', compact('personalis_bsm_2_sheets'));
    }

    public function import(Request $request)
    {
        // PersonalisBsm::truncate();
        // PersonalisBsmResult::truncate();
        // DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        // PersonlisBsmSheet::truncate();
        // DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        // dd('ada');
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls',
        ]);
        try {
            DB::beginTransaction();
            $file = $request->file('file');
            $records = Excel::toArray(new SheetImport, $file);
            // dd($records);

            // Get all existing submitter_ids from the receiving table
            $existingSubmitterIds = PersonalisBsm2::pluck('submitter_id')->toArray();
            $currentYear = Carbon::now()->year;
            $newRecords = collect();
            foreach ($records[0] as $key => $record) {
                // Skip the first row if it contains headers
                if ($key === 0) {
                    continue;
                }
                if (is_null($record[0]) && is_null($record[1]) && is_null($record[2]) && is_null($record[3])) {
                    continue;
                }
                // Skip records where submitter_id already exists in the database
                if (in_array($record[0], $existingSubmitterIds)) {
                    continue;
                }

                $newRecords->push([
                    'submitter_id' => $record[0],
                    'tracking_id' => $record[10],
                    'ship_date' => convertToDate2($record[11]) ?? '',
                ]);
            }
            // dd($newRecords);

            if ($newRecords->isNotEmpty()) {
                $bsm_sheet = PersonalisBsm2Sheet::create([
                    'name' => $file->getClientOriginalName()
                ]);

                // Assign the bsm_id to each new record
                $newRecords = $newRecords->map(function ($record) use ($bsm_sheet) {
                    $record['bsm2_id'] = $bsm_sheet->id;
                    return $record;
                });

                // Other logic like updating counts
                PersonalisBsm2::insert($newRecords->toArray());
            } else {
                // Handle the case where no new records are added
                return redirect()->back()->withError('No new records to upload. All records were duplicates.');
            }

            DB::commit();
            return redirect()->back()->withSuccess('Data Uploaded successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            dd($e->getMessage());
            return redirect()->back()->withError($e->getMessage());
            // return redirect()->back()->withError('Error Uploading Sheet (May be due to wrong sheet format)');

        }
    }

    public function export()
    {
        return Excel::download(new PersonalisBsm2Export(), 'productivity_data.xlsx');
    }

    public function show(Request $request)
    {
        // Fetch search inputs from request
        $name = $request->input('name');
        $date = $request->input('date');
        $from_date = $request->input('from_date');
        $to_date = $request->input('to_date');

        $personalisBsm2s = PersonalisBsm2::query()
            ->when($name, function ($query, $name) {
                return $query->where('name', 'like', "%{$name}%");
            })
            ->when($date, function ($query, $date) {
                return $query->where('ship_date', $date);
            })
            ->when($from_date && $to_date, function ($query) use ($from_date, $to_date) {
                return $query->whereBetween('ship_date', [$from_date, $to_date]);
            })
            ->get();

        // Total count of filtered items
        $totalCount = $personalisBsm2s->count();

        // Count of items with non-null tracking_id in the filtered set
        $shippedCount = $personalisBsm2s->whereNotNull('tracking_id')->count();

        // Calculate the percentage based on the filtered data
        $shippedPercentage = ($totalCount > 0) ? ($shippedCount / $totalCount) * 100 : 0;
        // dd($shippedPercentage);

        return view('personalis_bsm2.show', compact('personalisBsm2s', 'shippedPercentage'));
    }

    public function delete($id)
    {
        try {
            DB::beginTransaction();
            PersonalisBsm2::where('bsm2_id', $id)->delete();
            PersonalisBsm2Sheet::findOrFail($id)->delete();
            DB::commit();
            return redirect()->back()->withSuccess('Data Deleted successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->withError($e->getMessage());
        }
    }
}
