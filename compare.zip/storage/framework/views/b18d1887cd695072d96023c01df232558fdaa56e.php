
<?php $__env->startSection('content'); ?>
<div class="tab-content">
    <div class="tab-pane active" id="currentweek" role="tabpanel" aria-labelledby="currentweek-tab">
        <div class="container-fluid current-head">
            <div class="row">
                <div class="col-lg-6">
                    <h2>Total Records</h2>
                </div>

                <div class="col-lg-6">
                    
                </div>
            </div>
        </div>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
        <?php endif; ?>
        <div class="mainTable">
            <div class="container-fluid">
                <div class="bottomTable">
                    <table class="table dataTable">
                        <thead class="">
                            <tr>
                                <th>Submitter Id</th>
                                <th>Received By</th>
                                <th>Tracking</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody class="overflow-auto">
                            <?php $__currentLoopData = $receivingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->submitter_id); ?></td>
                                <td><?php echo e($data->received_by); ?></td>
                                <td><?php echo e($data->tracking); ?></td>
                                <td><?php echo e($data->received_date); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\laragon\www\compare\resources\views/receiving/show.blade.php ENDPATH**/ ?>