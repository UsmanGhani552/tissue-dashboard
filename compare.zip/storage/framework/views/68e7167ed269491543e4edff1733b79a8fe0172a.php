
<?php $__env->startSection('content'); ?>
<div class="tab-content">


    <div class="tab-pane active" id="currentweek" role="tabpanel" aria-labelledby="currentweek-tab">
        <div class="container-fluid current-head">
            <div class="row">
                <div class="col-lg-2">
                    <h2>Total Records</h2>
                </div>
                <div class="col-lg-10 margin-top" style="margin-top:-20px">
                    <form method="GET" action="<?php echo e(route('personalis_bsm.show')); ?>">
                        <div class="row align-items-end">
                            <div class="col">
                                <input type="text" name="name" class="form-control" placeholder="Search By Name" value="<?php echo e(request('name')); ?>">
                            </div>
                            <div class="col">
                                <label for="">Date</label>
                                <input type="date" name="date" class="form-control" placeholder="Search By Date" value="<?php echo e(request('date')); ?>">
                            </div>
                            <div class="col">
                                <label for="">From</label>
                                <input type="date" name="from_date" class="form-control" placeholder="Search By Date" value="<?php echo e(request('from_date')); ?>">
                            </div>
                            <div class="col">
                                <label for="">To</label>
                                <input type="date" name="to_date" class="form-control" placeholder="Search By Date" value="<?php echo e(request('to_date')); ?>">
                            </div>
                            <div class="col">
                                <button type="submit" class="btn btn-primary w-100">Search</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="d-flex justify-content-between">

                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#letter" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Letter</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#commentor" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Commentor</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#shipped_by" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Shipped By</button>
                    </li>
                </ul>
                <div>
                    <a href="<?php echo e(route('personalis_bsm')); ?>" class="btn btn-primary px-5">Back</a>
                </div>
            </div>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="letter" role="tabpanel" aria-labelledby="pills-home-tab">
                    <div class="mainTable">
                        <div class="container-fluid">
                            <div class="bottomTable">
                                <table class="table dataTable">
                                    <thead class="">
                                        <tr>
                                            <th>Id</th>
                                            <th>Name</th>
                                            <th>Count</th>
                                            <th>Ship date</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody class="overflow-auto">
                                        <?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($letter->id); ?></td>
                                            <td><?php echo e($letter->name); ?></td>
                                            <td><?php echo e($letter->count); ?></td>
                                            <td><?php echo e($letter->ship_date); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <table class="table">
                                    <thead class="">
                                        <tr>
                                            <th>Total Count</th>
                                        </tr>
                                    </thead>
                                    <tbody class="overflow-auto">
                                        <tr>
                                            <td><?php echo e($letterCount); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="commentor" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <div class="mainTable">
                        <div class="container-fluid">
                            <div class="bottomTable">
                                <table class="table dataTable">
                                    <thead class="">
                                        <tr>
                                            <th>Id</th>
                                            <th>Commentor</th>
                                            <th>Count</th>
                                            <th>Ship date</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody class="overflow-auto">
                                        <?php $__currentLoopData = $commentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($commentor->id); ?></td>
                                            <td><?php echo e($commentor->name); ?></td>
                                            <td><?php echo e($commentor->count); ?></td>
                                            <td><?php echo e($commentor->ship_date); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <table class="table">
                                    <thead class="">
                                        <tr>
                                            <th>Total Count</th>
                                        </tr>
                                    </thead>
                                    <tbody class="overflow-auto">
                                        <tr>
                                            <td><?php echo e($commentorCount); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="shipped_by" role="tabpanel" aria-labelledby="pills-contact-tab">
                    <div class="mainTable">
                        <div class="container-fluid">
                            <div class="bottomTable">
                                <table class="table dataTable">
                                    <thead class="">
                                        <tr>
                                            <th>Id</th>
                                            <th>Shipped By</th>
                                            <th>Count</th>
                                            <th>Ship date</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody class="overflow-auto">
                                        <?php $__currentLoopData = $shippedBys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shippedBy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($shippedBy->id); ?></td>
                                            <td><?php echo e($shippedBy->name); ?></td>
                                            <td><?php echo e($shippedBy->count); ?></td>
                                            <td><?php echo e($shippedBy->ship_date); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <table class="table">
                                    <thead class="">
                                        <tr>
                                            <th>Total Count</th>
                                        </tr>
                                    </thead>
                                    <tbody class="overflow-auto">
                                        <tr>
                                            <td><?php echo e($shippedByCount); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>

    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\laragon\www\compare\resources\views/personalis_bsm/show.blade.php ENDPATH**/ ?>