
<?php $__env->startSection('content'); ?>
<div class="tab-content">
    <div class="tab-pane active" id="currentweek" role="tabpanel" aria-labelledby="currentweek-tab">
        <div class="container-fluid current-head">
            <div class="row">
                <div class="col-lg-6">
                    <h2>Total Records</h2>
                </div>

                <div class="col-lg-6">
                    
                </div>
            </div>
        </div>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
        <?php endif; ?>
        <div class="mainTable">
            <div class="container-fluid">
                <div class="bottomTable">
                    <table class="table dataTable">
                        <thead class="">
                            <tr>
                                <th>Casefile Id</th>
                                <th>Barcode</th>
                                <th>Notesontube</th>
                                <th>Ship Destination Type</th>
                                <th>Rack Id</th>
                                <th>Name</th>
                                <th>Closing Notes</th>
                                <th>Closed</th>
                            </tr>
                        </thead>
                        <tbody class="overflow-auto">
                            <?php $__currentLoopData = $sheet2Data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->casefile_id); ?></td>
                                <td><?php echo e($data->barcode); ?></td>
                                <td><?php echo e($data->notesontube); ?></td>
                                <td><?php echo e($data->ship_destination_type); ?></td>
                                <td><?php echo e($data->rack_id); ?></td>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->closing_notes); ?></td>
                                <td><?php echo e($data->closed); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Downloads\laragon\www\compare\resources\views/sheet-2/show.blade.php ENDPATH**/ ?>