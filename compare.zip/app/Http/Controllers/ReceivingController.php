<?php

namespace App\Http\Controllers;

use App\Imports\SheetImport;
use App\Models\ErrorFile;
use App\Models\PersonalisBsm2;
use App\Models\PersonalisBsm2Sheet;
use App\Models\Receiving;
use App\Models\TrackingErrorFile;
use App\Services\DriveTokenService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;

use function PHPUnit\Framework\isNull;

class ReceivingController extends Controller
{
    public function index()
    {
        $receivings = Receiving::all();
        return view('receiving.index', compact('receivings'));
    }

    public function import(Request $request)
    {
        try {
            $folderId  = env('PRODUCTION_TRACKING');
            $drive_data = DriveTokenService::getDriveData($folderId,'2025-04-08T11:27:00');
            dd([$drive_data]);
            $this->readFile($drive_data);

            return redirect()->back()->withSuccess('Data Uploaded successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withError($e->getMessage());
            // return redirect()->back()->withError('Error Uploading Sheet (May be due to wrong sheet format)');
        }
    }

    public function _readFile($drive_data_file)
    {
        foreach ($drive_data_file as $records) {
            // dd($records);
            $fileName = $records['name'];

            $dataToStore = [];
            $isFailed = false;
            foreach ($records['content'] as $sheetkey => $record) {
                $data = $this->pageData($sheetkey, $record);
                if (is_string($data)) {
                    $isFailed = true;
                    // break;
                }
                $dataToStore[] = $this->pageData($sheetkey, $record);
            }

            // dd($dataToStore);
            if (!empty($dataToStore) && !empty($dataToStore[0]) && !$isFailed) {
                // dd($dataToStore);
                Receiving::create([
                    'name' => $fileName,
                    'data' => json_encode($dataToStore),
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now(),
                ]);
            } else {
                TrackingErrorFile::create([
                    'file_name' => $fileName,
                    'page_message' => json_encode($dataToStore),
                ]);
            }
        }
    }
    public function readFile($drive_data_file)
    {
        foreach ($drive_data_file as $records) {
            dd($records);
            $fileName = $records['name'];

            $dataToStore = [];
            $isFailed = false;
            foreach ($records['content'] as $sheetkey => $record) {
                $data = $this->pageData($sheetkey, $record);
                if (is_string($data)) {
                    $isFailed = true;
                    $dataToStore = [];
                    $dataToStore[] = $data;
                    break;
                }
                $dataToStore[] = $data;
            }
            if (!empty($dataToStore) && !empty($dataToStore[0]) && !$isFailed) {
                {
                    DB::beginTransaction();
                    $fileId = $records['id'];
                    $bsm_sheet = PersonalisBsm2Sheet::create(['sheet_id' => $fileId, 'name' => $fileName]);
                    $newRecords = array_map(function ($record) use ($bsm_sheet) {
                        $record['bsm2_id'] = $bsm_sheet->id;
                        return $record; 
                    }, $dataToStore[0]);
                    PersonalisBsm2::insert($newRecords);
                    DB::commit();
                }
            } else {
                ErrorFile::create([
                    'folder_id' => $this->folder_id,
                    'file_id' => $fileId,
                    'file_name' => $fileName,
                    'page_message' => json_encode($dataToStore),
                ]);
            }
        }
    }

    public function pageData($sheetkey, $records)
    {
        try {
            // finding header
            $keys = [];
            $rowIndex = -1;
            foreach ($records as $keyRowIndex => $record) {
                foreach ($record as $key => $recordValue) {
                    Log::info('header value: ' . $recordValue);
                    $value = Str::upper($recordValue);
                    if (Str::contains($value, ['SUBMITTER ID', 'NTRA_SAMPLE_ID'])) {
                        $keys[0] = $key;
                    } elseif (Str::contains($value, ['RECIEVED', 'RECEIVED', 'Recieved'])) {
                        $keys[1] = $key;
                    } elseif (Str::contains($value, ['TRACKING'])) {
                        $keys[2] = $key;
                    } elseif (Str::contains($value, ['SHIP DATE'])) {
                        $keys[3] = $key;
                    }
                }
                if (count($keys) > 3) {
                    $rowIndex = $keyRowIndex;
                    break;
                }
            }
            // dd($keys);
            if (!isset($keys[0], $keys[1], $keys[2], $keys[3])) {
                $keynotfound = '';
                if (!isset($keys[0]))
                    $keynotfound .= 'SUBMITTER ID, ';
                if (!isset($keys[1]))
                    $keynotfound .= 'RECIEVED, ';
                if (!isset($keys[2]))
                    $keynotfound .= 'TRACKING, ';
                if (!isset($keys[3]))
                    $keynotfound .= 'SHIP DATE, ';
                    // dd($keynotfound);
                return 'Error Uploading Sheet (May be due to wrong sheet format). keynotfound: ' . $keynotfound;
            }

            // finding values
            $dataToStore = [];

            foreach ($records as $key => $record) {
                // Skip the first row if it contains headers
                if ($key <= $rowIndex) {
                    continue;
                }
                
                if (empty($record) || is_null(value: $record[$keys[0]])) {
                    continue; // Skip this record
                }
                
                $dataToStore[] = [
                    'submitter_id' => $record[$keys[0]],
                    'tracking_id' => $record[$keys[2]] ?? '',
                    'ship_date' => isset($record[$keys[3]]) && $record[$keys[3]] ? $this->convertToDate($record[$keys[3]])->toDateString() : null,
                ];
            }
            return $dataToStore;
        } catch (\Throwable $th) {
            return 'Error Uploading Sheet (May be due to wrong sheet format): error: ' . $th->getMessage();
        }
    }
    public function convertToDate($dateValue)
    {
        if (is_numeric($dateValue)) {
            // Excel date system starts on January 1, 1900
            $baseDate = Carbon::createFromDate(1900, 1, 1);

            // Excel incorrectly treats 1900 as a leap year, so we subtract 1 day for dates after Feb 28, 1900
            if ($dateValue > 59) {
                $dateValue -= 1;
            }

            // Add the serial days to the base date
            return $baseDate->addDays($dateValue - 1); // Subtract 1 because the base date is already day 1
        } else {
            // If it's already in date format, use it directly
            return Carbon::parse($dateValue);
        }
    }
    public function show(Receiving $receiving)
    {
        $receivingData = json_decode($receiving->data);
        return view('receiving.show', compact('receivingData'));
    }

    public function delete(Receiving $receiving)
    {
        $receiving->delete();
        return redirect()->back()->withSuccess('Receiving Deleted Successfully');
    }
}
